<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in']!== true) {
    header("Location: admin_login.html");
    exit;
}

// 连接数据库
$conn = mysqli_connect("localhost", "blog", "123456", "blog");
if (!$conn) {
    die("数据库连接失败: ". mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $category_name = $_POST['category_name'];
    $sql = "INSERT INTO categories (name) VALUES ('$category_name')";
    if (mysqli_query($conn, $sql)) {
        echo "分类添加成功";
    } else {
        echo "分类添加失败: ". mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>添加文章分类</title>
</head>

<body>
    <h1>添加新文章分类</h1>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
        <label for="category_name">分类名称：</label><input type="text" id="category_name" name="category_name" required><br>
        <input type="submit" value="添加分类">
    </form>
</body>

</html>