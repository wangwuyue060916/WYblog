<?php
// 连接数据库
$conn = mysqli_connect("localhost", "blog", "123456", "blog");
if (!$conn) {
    die("数据库连接失败: ". mysqli_connect_error());
}

// 查询所有分类
$sql_categories = "SELECT * FROM categories";
$result_categories = mysqli_query($conn, $sql_categories);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>分类浏览</title>
    <style>
        /* 重置默认样式 */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* 整体页面通用样式 */
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-image: url('background.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: #fff;
        }

        /* 页面头部样式 */
        header {
            background-color: rgba(0, 0, 0, 0.5);
            text-align: center;
            padding: 20px;
        }

        header h1 {
            font-size: 48px;
            margin-bottom: 10px;
        }

        header p {
            font-size: 18px;
            color: #ccc;
        }

        /* 容器样式，用于包裹内容并设置合适的宽度和边距 */
      .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background-color: rgba(0, 0, 0, 0.7);
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }

        /* 分类列表标题样式 */
        h2 {
            color: #fff;
            border-bottom: 2px solid #ccc;
            padding-bottom: 10px;
            font-size: 32px;
            margin-bottom: 20px;
        }

        /* 分类项样式 */
      .category-item {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 20px;
            background-color: rgba(255, 255, 255, 0.1);
            transition: transform 0.3s ease;
        }

      .category-item:hover {
            transform: scale(1.02);
        }

        /* 分类名称样式 */
      .category-item h3 {
            margin-top: 0;
            color: #fff;
            font-size: 24px;
        }

        /* 文章列表项通用样式 */
      .article-item {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            margin-top: 10px;
            background-color: rgba(255, 255, 255, 0.1);
            transition: transform 0.3s ease;
        }

      .article-item:hover {
            transform: scale(1.02);
        }

        /* 文章标题样式 */
      .article-item h4 {
            margin-top: 0;
            color: #fff;
            font-size: 20px;
        }

        /* 文章链接样式 */
      .article-item a {
            text-decoration: none;
            color: inherit;
            transition: color 0.3s ease;
        }

      .article-item a:hover {
            color: #007bff;
        }
    </style>
</head>

<body>
    <header>
        <h1>分类浏览</h1>
        <p>探索不同主题下的精彩文章</p>
    </header>
    <div class="container">
        <?php
        while ($category = mysqli_fetch_assoc($result_categories)) {
            $category_id = $category['id'];
            $category_name = $category['name'];
            // 根据分类ID查询该分类下的文章
            $sql_articles = "SELECT * FROM articles WHERE category_id = $category_id";
            $result_articles = mysqli_query($conn, $sql_articles);
           ?>
            <div class="category-item">
                <h3><?php echo $category_name;?></h3>
                <?php
                while ($article = mysqli_fetch_assoc($result_articles)) {
                    $article_id = $article['id'];
                    $article_title = $article['title'];
                   ?>
                    <div class="article-item">
                        <h4><a href="article_detail.php?id=<?php echo $article_id;?>"><?php echo $article_title;?></a></h4>
                    </div>
                    <?php
                }
               ?>
            </div>
            <?php
        }
       ?>
    </div>
</body>

</html>