<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in']!== true) {
    header("Location: admin_login.html");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>管理后台</title>
</head>

<body>
    <h1>欢迎，<?php echo $_SESSION['username'];?>管理员</h1>
    <a href="write_article.php">写文章</a><br>
    <a href="manage_categories.php">管理文章分类</a><br>
    <a href="manage_articles.php">管理文章（包括删除等操作）</a><br>
</body>

</html>