<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in']!== true) {
    header("Location: admin_login.html");
    exit;
}

// 连接数据库
$conn = mysqli_connect("localhost", "blog", "123456", "blog");
if (!$conn) {
    die("数据库连接失败: ". mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $category_id = $_POST['category_id'];
    $sql = "INSERT INTO articles (title, content, category_id) VALUES ('$title', '$content', '$category_id')";
    if (mysqli_query($conn, $sql)) {
        echo "文章发布成功";
    } else {
        echo "文章发布失败: ". mysqli_error($conn);
    }
}

// 查询分类用于下拉选择
$sql_categories = "SELECT * FROM categories";
$result_categories = mysqli_query($conn, $sql_categories);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>写文章</title>
</head>

<body>
    <h1>撰写新文章</h1>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
        <label for="title">文章标题：</label><input type="text" id="title" name="title" required><br>
        <label for="content">文章内容：</label><textarea id="content" name="content" required></textarea><br>
        <label for="category">文章分类：</label>
        <select id="category_id" name="category_id">
            <?php
            while ($row = mysqli_fetch_assoc($result_categories)) {
                echo '<option value="'. $row['id']. '">'. $row['name']. '</option>';
            }
           ?>
        </select><br>
        <input type="submit" value="发布文章">
    </form>
</body>

</html>