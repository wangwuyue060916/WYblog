<?php
// 显示所有错误信息，方便调试安装过程中出现的问题（在正式环境可关闭或设置合适的错误级别）
ini_set('display_errors', 1);
error_reporting(E_ALL);

// 预设数据库连接配置，根据实际情况修改这里的配置参数
$servername = "localhost";
$username = "blog";
$password = "123456";
$dbname = "blog";

// 创建连接
$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("数据库连接失败: ". mysqli_connect_error());
}

// SQL语句用于创建文章表（articles）
$sql_articles = "CREATE TABLE IF NOT EXISTS articles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    category_id INT,
    image_path VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);";

// SQL语句用于创建分类表（categories）
$sql_categories = "CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL
);";

// SQL语句用于创建评论表（comments）
$sql_comments = "CREATE TABLE IF NOT EXISTS comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    article_id INT NOT NULL,
    commenter_name VARCHAR(255),
    comment_text TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (article_id) REFERENCES articles(id)
);";

// SQL语句用于创建管理员表（admins）
$sql_admins = "CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL
);";

// 尝试执行创建表的SQL语句
if (
    mysqli_query($conn, $sql_articles) &&
    mysqli_query($conn, $sql_categories) &&
    mysqli_query($conn, $sql_comments) &&
    mysqli_query($conn, $sql_admins)
) {
    // 插入初始管理员账号（示例，密码应该存储加密后的形式，这里为了简单演示直接用明文，实际中请使用密码哈希函数处理）
    $sql_insert_admin = "INSERT INTO admins (username, password) VALUES ('admin', '123456')";
    if (mysqli_query($conn, $sql_insert_admin)) {
        echo "博客系统安装成功！<br>";
        echo "你可以使用以下管理员账号登录后台：<br>";
        echo "用户名：admin<br>";
        echo "密码：123456<br>";
        echo "请及时修改初始密码以保障安全。<br>";
    } else {
        echo "初始管理员账号插入失败，请检查数据库设置: ". mysqli_error($conn);
    }
} else {
    echo "数据库表创建失败，请检查SQL语句或数据库权限: ". mysqli_error($conn);
}

mysqli_close($conn);
?>