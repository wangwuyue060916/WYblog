<?php
session_start();
// 连接数据库
$conn = mysqli_connect("localhost", "blog", "123456", "blog");
if (!$conn) {
    die("数据库连接失败: ". mysqli_connect_error());
}

$username = $_POST['username'];
$password = $_POST['password'];

// 查询数据库验证管理员账号密码
$sql = "SELECT * FROM admins WHERE username = '$username' AND password = '$password'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $_SESSION['admin_logged_in'] = true;
    $_SESSION['username'] = $username;
    header("Location: admin_dashboard.php");
} else {
    echo "用户名或密码错误，请重新登录";
}

mysqli_close($conn);
?>