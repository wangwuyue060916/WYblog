<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in']!== true) {
    header("Location: admin_login.html");
    exit;
}

// 连接数据库
$conn = mysqli_connect("localhost", "blog", "123456", "blog");
if (!$conn) {
    die("数据库连接失败: ". mysqli_connect_error());
}

if (isset($_GET['id'])) {
    $category_id = $_GET['id'];
    // 先检查该分类下是否有文章关联，若有则不允许删除（这里简单提示，实际可更完善处理）
    $sql_check_articles = "SELECT * FROM articles WHERE category_id = '$category_id'";
    $result_check_articles = mysqli_query($conn, $sql_check_articles);
    if (mysqli_num_rows($result_check_articles) > 0) {
        echo "该分类下存在文章，不能删除，请先调整文章分类。";
        exit;
    }
    $sql = "DELETE FROM categories WHERE id = '$category_id'";
    if (mysqli_query($conn, $sql)) {
        header("Location: manage_categories.php");
    } else {
        echo "分类删除失败: ". mysqli_error($conn);
    }
}

mysqli_close($conn);
?>