<?php
// 连接数据库（此页面若无需数据库操作可省略这部分，这里假设保留数据库连接，可按需拓展功能）
$conn = mysqli_connect("localhost", "blog", "123456", "blog");
if (!$conn) {
    die("数据库连接失败: ". mysqli_connect_error());
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>关于我</title>
    <style>
        /* 重置默认样式 */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* 整体页面通用样式 */
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-image: url('background.jpg'); /* 沿用之前的二次元背景图片，确保路径正确 */
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: #fff;
        }

        /* 页面头部样式 */
        header {
            background-color: rgba(0, 0, 0, 0.5);
            text-align: center;
            padding: 20px;
        }

        header h1 {
            font-size: 48px;
            margin-bottom: 10px;
        }

        header p {
            font-size: 18px;
            color: #ccc;
        }

        /* 容器样式，用于包裹内容并设置合适的宽度和边距 */
     .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background-color: rgba(0, 0, 0, 0.7);
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }

        /* 个人简介区域样式 */
       .profile {
            text-align: center;
            margin-bottom: 30px;
        }

       .profile img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #fff;
            margin-bottom: 15px;
        }

       .profile h2 {
            font-size: 32px;
            margin-bottom: 10px;
        }

       .profile p {
            font-size: 18px;
            color: #ccc;
        }

        /* 兴趣爱好列表样式 */
       .hobbies ul {
            list-style-type: none;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

       .hobbies ul li {
            background-color: rgba(255, 255, 255, 0.1);
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px 15px;
            margin: 5px;
            font-size: 16px;
            transition: transform 0.3s ease;
        }

       .hobbies ul li:hover {
            transform: scale(1.05);
        }

        /* 经历板块样式 */
       .experiences h2 {
            color: #fff;
            border-bottom: 2px solid #ccc;
            padding-bottom: 10px;
            font-size: 32px;
            margin-bottom: 20px;
        }

       .experiences.experience-item {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 20px;
            background-color: rgba(255, 255, 255, 0.1);
            transition: transform 0.3s ease;
        }

       .experiences.experience-item:hover {
            transform: scale(1.02);
        }

       .experiences.experience-item h3 {
            margin-top: 0;
            color: #fff;
            font-size: 24px;
        }

       .experiences.experience-item p {
            margin: 5px 0;
            font-size: 16px;
            color: #ccc;
        }
    </style>
</head>

<body>
    <header>
        <h1>关于我</h1>
        <p>走进博主的二次元小天地</p>
    </header>
    <div class="container">
        <div class="profile">
            <img src="me.jpg" alt="头像"> <!-- 替换为你的头像图片路径及文件名 -->
            <h2>初无月</h2>
            <p>热爱二次元文化，钟情于动漫、游戏与轻小说，在此分享独特见解与精彩故事。日常沉浸在奇幻的二次元世界，期望通过博客与更多同好交流心得，传递热爱。</p>
        </div>
        <div class="hobbies">
            <h2>兴趣爱好</h2>
            <ul>
                <li>追番</li>
                <li>打游戏</li>
                <li>敲代码</li>
                <li>看小说</li>
            </ul>
        </div>
        <div class="experiences">
            <h2>二次元经历点滴</h2>
            <div class="experience-item">
                <h3>初次邂逅二次元</h3>
                <p>还记得那是一个夏日午后，偶然打开电视看到一部热血动漫，从此便踏入了二次元的奇妙大门，被精美的画风、跌宕起伏的剧情深深吸引。</p>
            </div>
            <div class="experience-item">
                <h3>难忘的漫展之行</h3>
                <p>参加了本地的大型漫展，穿梭在琳琅满目的摊位间，与coser们互动合影（并没有，社恐），那种沉浸在二次元氛围的热烈感觉至今难忘，也更加坚定了在这个领域探索分享的决心。</p>
            </div>
        </div>
    </div>
</body>

</html>