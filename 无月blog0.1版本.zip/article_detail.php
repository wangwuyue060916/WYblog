<?php
// 连接数据库
$conn = mysqli_connect("localhost", "blog", "123456", "blog");
if (!$conn) {
    die("数据库连接失败: ". mysqli_connect_error());
}

if (isset($_GET['id'])) {
    $article_id = $_GET['id'];
    // 查询文章详情
    $sql_article = "SELECT * FROM articles WHERE id = '$article_id'";
    $result_article = mysqli_query($conn, $sql_article);
    $article = mysqli_fetch_assoc($result_article);
    // 查询文章评论
    $sql_comments = "SELECT * FROM comments WHERE article_id = '$article_id'";
    $result_comments = mysqli_query($conn, $sql_comments);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $article_id = isset($_POST['article_id'])? intval($_POST['article_id']) : 0; // 获取并转换为整数类型，若不存在设为0（可根据实际调整默认值）
    $commenter_name = $_POST['name'];
    $comment_text = $_POST['comment'];
    $sql_insert_comment = "INSERT INTO comments (article_id, commenter_name, comment_text) VALUES ($article_id, '$commenter_name', '$comment_text')";
    if (mysqli_query($conn, $sql_insert_comment)) {
        // 插入成功后可以选择刷新页面等操作来展示新评论
        header("Location: article_detail.php?id=$article_id");
    } else {
        echo "评论提交失败: ". mysqli_error($conn);
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>文章详情</title>
    <style>
        /* 整体页面通用样式 */
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        /* 页面头部样式 */
        header {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 20px;
        }

        /* 容器样式，用于包裹内容并设置合适的宽度和边距 */
      .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }

        /* 文章标题样式 */
        h1 {
            color: #333;
            margin-top: 0;
        }

        /* 文章内容样式 */
      .article-content {
            margin-bottom: 20px;
            padding-bottom: 20px;
            border-bottom: 1px solid #ccc;
        }

        /* 评论区域标题样式 */
        h2 {
            color: #333;
            margin-top: 20px;
            border-bottom: 2px solid #ccc;
            padding-bottom: 10px;
        }

        /* 评论表单样式 */
        form#comment-form {
            margin-bottom: 20px;
        }

        form#comment-form label {
            display: block;
            margin-bottom: 5px;
        }

        form#comment-form input[type="text"],
        form#comment-form textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        form#comment-form input[type="submit"] {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        form#comment-form input[type="submit"]:hover {
            background-color: #0056b3;
        }

        /* 单个评论样式 */
      .comment-item {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 15px;
            background-color: #f9f9f9;
        }

        /* 评论者姓名样式 */
      .comment-item strong {
            color: #333;
            font-size: 16px;
        }

    </style>
</head>

<body>
    <header>
        <h1>文章详情</h1>
    </header>
    <div class="container">
        <h1 id="article-title"><?php echo $article['title'];?></h1>
        <div class="article-content"><?php echo $article['content'];?></div>
        <h2>评论</h2>
<form id="comment-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
    <label for="name">您的姓名：</label><input type="text" id="name" name="name" required><br>
    <label for="comment">评论内容：</label><textarea id="comment" name="comment" required></textarea><br>
    <!-- 添加隐藏字段传递 article_id -->
    <input type="hidden" id="article_id" name="article_id" value="<?php echo $article_id;?>">
    <input type="submit" value="提交评论">
</form>
        </form>
        <div id="comments-list">
            <?php
            while ($comment = mysqli_fetch_assoc($result_comments)) {
                echo '<div class="comment-item">';
                echo '<p><strong>'. $comment['commenter_name']. '</strong> 说： '. $comment['comment_text']. '</p>';
                echo '</div>';
            }
          ?>
        </div>
    </div>
</body>

</html>