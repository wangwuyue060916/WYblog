<?php
// 连接数据库
$conn = mysqli_connect("localhost", "blog", "123456", "blog");
if (!$conn) {
    die("数据库连接失败: ". mysqli_connect_error());
}

// 查询热门文章（按评论数量降序取几条示例，可调整数量和具体逻辑）
$sql = "SELECT a.*, COUNT(c.id) AS comment_count
        FROM articles a
        LEFT JOIN comments c ON a.id = c.article_id
        GROUP BY a.id
        ORDER BY comment_count DESC
        LIMIT 3";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>博客主页</title>
    <style>
        /* 重置默认样式 */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* 整体页面通用样式 */
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-image: url('background.jpg'); /* 设置二次元背景图片 */
            background-size: cover; /* 让背景图片覆盖整个页面 */
            background-position: center; /* 图片居中显示 */
            background-attachment: fixed; /* 固定背景，页面滚动时背景不动 */
            color: #fff; /* 文字颜色设为白色，以便在背景上清晰显示 */
        }

        /* 页面头部样式 */
        header {
            background-color: rgba(0, 0, 0, 0.5); /* 半透明黑色背景，增强文字可读性 */
            text-align: center;
            padding: 20px;
        }

        header h1 {
            font-size: 48px;
            margin-bottom: 10px;
        }

        header p {
            font-size: 18px;
            color: #ccc; /* 副标题颜色稍淡一些 */
        }

        /* 容器样式，用于包裹内容并设置合适的宽度和边距 */
      .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background-color: rgba(0, 0, 0, 0.7); /* 半透明黑色容器背景，与页面整体协调 */
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); /* 添加阴影效果 */
        }

        /* 文章列表项通用样式 */
      .article-item {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 20px;
            background-color: rgba(255, 255, 255, 0.1); /* 文章项有淡淡的白色透明背景 */
            transition: transform 0.3s ease; /* 添加鼠标悬停时的缩放动画效果 */
        }

       .article-item:hover {
            transform: scale(1.02); /* 鼠标悬停时放大一点 */
        }

        /* 文章标题样式 */
      .article-item h3 {
            margin-top: 0;
            color: #fff;
            font-size: 24px;
        }

        /* 文章链接样式 */
      .article-item a {
            text-decoration: none;
            color: inherit;
            transition: color 0.3s ease;
        }

      .article-item a:hover {
            color: #007bff;
        }

        /* 评论数样式 */
      .article-item p {
            margin: 5px 0;
            font-size: 14px;
            color: #ccc;
        }

        /* 热门文章标题样式 */
        h2 {
            color: #fff;
            border-bottom: 2px solid #ccc;
            padding-bottom: 10px;
            font-size: 32px;
            margin-bottom: 20px;
        }

        /* 导航栏样式 */
        nav {
            background-color: rgba(0, 0, 0, 0.5);
            padding: 10px 0;
            text-align: center;
        }

        nav ul {
            list-style-type: none;
        }

        nav ul li {
            display: inline-block;
            margin: 0 15px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-size: 18px;
            transition: color 0.3s ease;
        }

        nav ul li a:hover {
            color: #007bff;
        }
    </style>
</head>

<body>
    <header>
        <h1>欢迎来到我的博客</h1>
        <p>二次元世界里的精彩分享</p>
    </header>
    <nav>
        <ul>
            <li><a href="#">首页</a></li>
            <li><a href="category_browse.php">分类浏览</a></li>
            <li><a href="about_me.php">关于我</a></li>
        </ul>
    </nav>
    <div class="container">
        <h2>热门文章</h2>
        <div id="popular-articles">
            <?php
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<div class="article-item">';
                echo '<h3><a href="article_detail.php?id='. $row['id']. '">'. $row['title']. '</a></h3>';
                echo '<p>评论数：'. $row['comment_count']. '</p>';
                echo '</div>';
            }
          ?>
        </div>
        <h2>最新文章</h2>
        <div id="latest-articles">
            <?php
            // 查询最新文章逻辑（按创建时间降序取几条示例）
            $sql_latest = "SELECT * FROM articles ORDER BY created_at DESC LIMIT 5";
            $result_latest = mysqli_query($conn, $sql_latest);
            while ($article = mysqli_fetch_assoc($result_latest)) {
                echo '<div class="article-item">';
                echo '<h3><a href="article_detail.php?id='. $article['id']. '">'. $article['title']. '</a></h3>';
                echo '</div>';
            }
          ?>
        </div>
    </div>
</body>

</html>