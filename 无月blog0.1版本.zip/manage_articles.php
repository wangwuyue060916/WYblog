<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in']!== true) {
    header("Location: admin_login.html");
    exit;
}

// 连接数据库
$conn = mysqli_connect("localhost", "blog", "123456", "blog");
if (!$conn) {
    die("数据库连接失败: ". mysqli_connect_error());
}

$sql = "SELECT * FROM articles";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>管理文章</title>
</html>

<body>
    <h1>文章管理</h1>
    <table border="1">
        <tr>
            <th>文章标题</th>
            <th>操作</th>
        </tr>
        <?php
        while ($row = mysqli_fetch_assoc($result)) {
            echo '<tr>';
            echo '<td>'. $row['title']. '</td>';
            echo '<td><a href="delete_article.php?id='. $row['id']. '">删除</a></td>';
            echo '</tr>';
        }
       ?>
    </table>
</body>

</html>