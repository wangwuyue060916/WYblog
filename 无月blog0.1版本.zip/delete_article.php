<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in']!== true) {
    header("Location: admin_login.html");
    exit;
}

// 连接数据库
$conn = mysqli_connect("localhost", "blog", "123456", "blog");
if (!$conn) {
    die("数据库连接失败: ". mysqli_connect_error());
}

if (isset($_GET['id'])) {
    $article_id = $_GET['id'];
    // 先删除该文章对应的所有评论记录
    $sql_delete_comments = "DELETE FROM comments WHERE article_id = '$article_id'";
    if (mysqli_query($conn, $sql_delete_comments)) {
        // 再删除文章记录
        $sql = "DELETE FROM articles WHERE id = '$article_id'";
        if (mysqli_query($conn, $sql)) {
            header("Location: manage_articles.php");
        } else {
            echo "文章删除失败: ". mysqli_error($conn);
        }
    } else {
        echo "评论删除失败，无法删除文章: ". mysqli_error($conn);
    }
}

mysqli_close($conn);
?>